from django.db import models

# Create your models here.
class account(models.Model):
    gmail = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.gmail}"
    

class data_account(models.Model):
    nama = models.ForeignKey(account, on_delete=models.CASCADE)
    jabatan = models.CharField(max_length=100)
    
    def __str__(self):
        return f"{self.jabatan}"
    