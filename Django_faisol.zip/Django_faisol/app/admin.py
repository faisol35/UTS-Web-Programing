from django.contrib import admin
from.models import data_account, account

# Register your models here.
class data_accountAdmin(admin.ModelAdmin):
    list_display = ('jabatan',)
    


admin.site.register(data_account, data_accountAdmin)
admin.site.register(account)